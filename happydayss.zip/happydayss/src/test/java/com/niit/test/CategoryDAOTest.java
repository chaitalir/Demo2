package com.niit.test;

import static org.junit.Assert.*;




import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CategoryDao;
import com.niit.model.Category;

//import net.kzn.shoppingbackend.dao.CategoryDAO;

//import net.kzn.shoppingbackend.test.AnnotationConfigApplicationContext;

//import net.kzn.shoppingbackend.test.AnnotationConfigApplicationContext;

//import net.kzn.shoppingbackend.dao.CategoryDAO;

public class CategoryDAOTest {

private static AnnotationConfigApplicationContext context;
	
	
	private static CategoryDao categoryDao;
	
	
	//private Category category;
	
	
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		categoryDao = (CategoryDao)context.getBean("categoryDao");
	}
	
	
	
		 @Test
		 public final void addCategoryTest()
		 {
			 Category category=new Category();
			 category.setMaincategory("flowers");
			 category.setSubcategory("rose");
			 //category.setActive(true);
			 System.out.println(category);
			// categoryDao.addCategory(category);
			 assertEquals("Successfully added a category inside the table!",true,categoryDao.addCategory(category));
			 
		 }
		 @Ignore
		 @Test
		 public void updateCategoryTest()
		 {
			 Category category=categoryDao.getCategory(3);
			 category.setMaincategory("All the xiomi mobile with smart features");
			 assertTrue("Problem in updating category::",categoryDao.updateCategory(category,3));

		 }
		 @Ignore
		 @Test
		 public void deleteCategoryTest()
		 {
			 Category category=categoryDao.getCategory(4);
			// category.setCategoryDesc("All the xiomi mobile with smart features");
			 assertTrue("Problem in deleting category::",categoryDao.deleteCategory(category));

		 }
		 @Ignore
		 @Test
		 public void listCategoryTest()
		 {
			 List<Category>listCategories=categoryDao.listCategories();
			 assertNotNull("Problem in listing category::",listCategories);
			 for( Category category:listCategories)
			 {
				 System.out.println(category.getCategoryId()+"");
				 System.out.println(category.getMaincategory()+"");
				 System.out.println(category.getSubcategory()+"");
			 }
		 }
		 
	 }

