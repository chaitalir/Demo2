package com.niit.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.SupplierDao;
import com.niit.model.Supplier;

//import com.niit.dao.ProductDao;
//import com.niit.model.Product;

public class SupplierDAOTest {

private static AnnotationConfigApplicationContext context;
	
	
	private static SupplierDao supplierDao;
	
	
	private Supplier supplier;
	
	
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		supplierDao = (SupplierDao)context.getBean("supplierDao");
	}
	
	
	
		 @Test
		 public final void addProductTest()
		 {
			 Supplier supplier=new Supplier();
			 supplier.setSupplierName("supplier4");
			 supplier.setAddress("delhi");
			 
			 //category.setActive(true);
			 System.out.println(supplier);
			// categoryDao.addCategory(category);
			 assertTrue("Successfully added a product inside the table!",supplierDao.addSupplier(supplier));
			 
		 }
		 @Ignore
		 @Test
		 public void updateSupplierTest()
		 {
			 Supplier supplier=supplierDao.getSupplier(3);
			 supplier.setSupplierName("All the xiomi mobile with smart features");
			 assertTrue("Problem in updating Supplier::",supplierDao.updateSupplier(supplier));

		 }
		 @Ignore
		 @Test
		 public void deleteSupplierTest()
		 {
			 Supplier supplier=supplierDao.getSupplier(4);
			// category.setCategoryDesc("All the xiomi mobile with smart features");
			 assertTrue("Problem in deleting Supplier::",supplierDao.deleteSupplier(supplier));

		 }
		 @Ignore
		 @Test
		 public void listSupplierTest()
		 {
			 List<Supplier>listSupplier=supplierDao.listSuppliers();
			 assertNotNull("Problem in listing Supplier::",listSupplier);
			 for( Supplier supplier:listSupplier)
			 {
				 System.out.println(supplier.getSupplierId()+"");
				 System.out.println(supplier.getSupplierName()+"");
				 System.out.println(supplier.getAddress()+"");
			 }
		 }
		 
}
