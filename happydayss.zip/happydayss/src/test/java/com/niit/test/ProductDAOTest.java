package com.niit.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CategoryDao;
import com.niit.dao.ProductDao;
import com.niit.model.Category;
import com.niit.model.Product;

public class ProductDAOTest {

private static AnnotationConfigApplicationContext context;
	
	
	private static ProductDao productDao;
	
	
	//private Category category;
	
	
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		productDao = (ProductDao)context.getBean("productDao");
	}
	
	
	
		 @Test
		 public final void addProductTest()
		 {
			 Product product=new Product();
			// product.setProductName("vivo");
			// product.setProductDesc("selfie 4g mobile");
			// product.setPrice(25000);
			// product.setQuantity(4);
			// product.setSupplierId(4);
			/// product.setCategoryId(4);
			
			 System.out.println(product);
			
			 assertTrue("Successfully added a product inside the table!",productDao.addProduct(product));
			 
		 }
		 @Ignore
		 @Test
		 public void updateProductTest()
		 {
			 Product product=productDao.getProduct(3);
			// product.setProductDesc("All the xiomi mobile with smart features");
			// assertTrue("Problem in updating product::",productDao.updateProduct(product));

		 }
		 @Ignore
		 @Test
		 public void deleteProductTest()
		 {
			 Product product=productDao.getProduct(4);
			// category.setCategoryDesc("All the xiomi mobile with smart features");
			 assertTrue("Problem in deleting product::",productDao.deleteProduct(product));

		 }
		 @Ignore
		 @Test
		 public void listProductTest()
		 {
			 List<Product>listProducts=productDao.listProducts();
			 assertNotNull("Problem in listing category::",listProducts);
			 for( Product product:listProducts)
			 {
				// System.out.println(product.getProductId()+"");
				// System.out.println(product.getProductName()+"");
				// System.out.println(product.getProductDesc()+"");
			 }
		 }
		 
}
