package com.niit.test;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

//import com.niit.dao.CategoryDao;
import com.niit.dao.UserDao;
import com.niit.model.User;
//import com.niit.model.Category;

public class UserDAOTest {

	private static AnnotationConfigApplicationContext context;

	private static UserDao userDao;
	
	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		userDao = (UserDao)context.getBean("userDao");
	}
	
	
	 @Test
	 public final void addCategoryTest()
	 {
		 User user=new User();
		 user.setUserName("Ram2");;
		 user.setCustomerName("Ram Padalkar");
		 user.setPassword("chaitu2");
		 user.setEmailId("ram@gmail.com");
		 user.setRole("Role_Admin");
		 user.setEnabled("true");
		 user.setMobileNo("9975055158");
		 //category.setActive(true);
		 System.out.println(user);
		// categoryDao.addCategory(category);
		 assertEquals("Successfully added a category inside the table!",true,userDao.register(user));
		 
	 }
}
