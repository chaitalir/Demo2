package com.niit.dao;

import java.util.List;


import com.niit.model.CartItem;

public interface CartDao {

	public void save(CartItem cartItem);
	public List<CartItem> prodInCart();
	public void deleteCartItem(CartItem cartItem);
	public void flushCart();
	public int getProductcount();
	public List prodInCart2(String username);
}
