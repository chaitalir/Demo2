package com.niit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Category;
import com.niit.model.OrderedProduct2;
import com.niit.model.PlacingOrder;

@Repository("placeOrderDao")
@Transactional
public class PlaceOrderDaoImpl implements PlaceOrderDao {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<PlacingOrder> getPlacedOrder() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from PlacingOrder");
		List<PlacingOrder>getPlacedOrder=query.list();
		session.close();
		return getPlacedOrder;
	}

	@Override
	public void saveproductorder(OrderedProduct2 orderedProduct2) {
		try
		{
			System.out.println("came.....");
			sessionFactory.getCurrentSession().save(orderedProduct2);
			System.out.println("saved.....");
			//return true;
		}
		catch(Exception e)
		{
			System.out.println("not saved.......");
			//return false;
		}
		
	}

	@Override
	public List<OrderedProduct2> getorders() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from OrderedProduct2");
		List<OrderedProduct2>getorders=query.list();
		session.close();
		return getorders;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public OrderedProduct2 getIdOfProductstored() {
		Session session=sessionFactory.openSession();
		OrderedProduct2 id=(OrderedProduct2) session.createQuery("from OrderedProduct2 ORDER BY id DESC")
				.setMaxResults(1)
                .uniqueResult();
		//=query.
                
		
		return id;
	}

	@Override
	public OrderedProduct2 getProducts(long productid) {
		Session session=sessionFactory.openSession();
		return (OrderedProduct2) session.createQuery(
		        "from OrderedProduct2 where id = :productid")
		        .setParameter("productid", productid)
		        .uniqueResult();
	}

	@Override
	public PlacingOrder getLastUpdatedRecored() {
		Session session=sessionFactory.openSession();
		Query query = session.createQuery("from PlacingOrder order by id DESC");
		query.setMaxResults(1);
		PlacingOrder  placingOrder = (PlacingOrder) query.uniqueResult();//TODO Auto-generated method stub
		return  placingOrder;
	}

	@Override
	public void savedeliverydetails(PlacingOrder placingOrder) {
		try
		{
			System.out.println("came.....");
			sessionFactory.getCurrentSession().save(placingOrder);
			System.out.println("saved.....");
			//return true;
		}
		catch(Exception e)
		{
			System.out.println("not saved.......");
			//return false;
		}
		
	}
}
