package com.niit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Category;
import com.niit.model.Contact;

@Repository("contactDao")
@Transactional
public class ContactDaoImpl implements ContactDao {

	@Autowired
	SessionFactory sessionFactory;
	
	
	@Override
	public boolean addContact(Contact contact) {
		try
		{
			System.out.println("came.....");
			sessionFactory.getCurrentSession().save(contact);
			System.out.println("saved.....");
			return true;
		}
		catch(Exception e)
		{
			System.out.println("not saved.......");
			return false;
		}
	}

	@Override
	public List<Contact> listContacts() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Contact");
		List<Contact>listContacts=query.list();
		session.close();
		return listContacts;
	}

	@Override
	public boolean deleteContact(Contact contact) {
		try {
			// add the category to the database table
			
			sessionFactory.getCurrentSession().delete(contact);
			//,sessionFactory.openSession().clear();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}

	@Override
	public Contact getContact(int ContactId) {
		Session session=sessionFactory.openSession();
		Contact contact=session.get(Contact.class, ContactId);
		session.close();
		return contact;
	}

}
