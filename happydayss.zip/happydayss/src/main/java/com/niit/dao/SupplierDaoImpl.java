package com.niit.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Supplier;
@Repository("supplierDao")
@Transactional
public class SupplierDaoImpl implements SupplierDao {

	@Autowired
	SessionFactory sessionFactory;
	@Override
	public boolean addSupplier(Supplier supplier) {
		try
		{
			System.out.println("came.....");
			sessionFactory.getCurrentSession().save(supplier);
			System.out.println("saved.....");
			return true;
		}
		catch(Exception e)
		{
			System.out.println("not saved.......");
			return false;
		}
	}

	@Override
	public boolean deleteSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Supplier> listSuppliers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Supplier getSupplier(int supplierId) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
