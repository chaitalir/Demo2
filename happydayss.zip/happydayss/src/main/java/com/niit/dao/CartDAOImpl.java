package com.niit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.CartItem;
import com.niit.model.Product;
@Repository("cartDao")
@Transactional
public class CartDAOImpl implements CartDao {


	@Autowired
	SessionFactory sessionFactory;
	
	
	@Override
	public void save(CartItem cartItem) {
		try
		{
			System.out.println("came.....");
			sessionFactory.getCurrentSession().save(cartItem);
			System.out.println("saved.....");
			
		}
		catch(Exception e)
		{
			System.out.println("not saved.......");
			
		}
		
		
	}

	@Override
	public List<CartItem> prodInCart() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from CartItem");
		List<CartItem>prodInCart=query.list();
		session.close();
		return prodInCart;
	}

	@Override
	public void deleteCartItem(CartItem cartItem) {
		try {
			// add the category to the database table
			
			sessionFactory.getCurrentSession().delete(cartItem);
			//,sessionFactory.openSession().clear();
		
		} catch (Exception ex) {
			ex.printStackTrace();
		
		}
		
	}

	@Override
	public void flushCart() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getProductcount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List prodInCart2(String username) {
		Session session=sessionFactory.openSession();
		System.out.println("in dao..of cat");
		Query query=session.createQuery("Select e from CartItem e where e.username=:username").setParameter("username", username);
		
		List<CartItem>prodInCart2=query.list();
		session.close();
		return prodInCart2;
	}

}
