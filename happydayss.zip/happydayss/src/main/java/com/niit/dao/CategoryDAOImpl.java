package com.niit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Category;

//import net.kzn.shoppingbackend.daoimpl.Query;
@Repository("categoryDao")
@Transactional
public class CategoryDAOImpl implements CategoryDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public boolean addCategory(Category category) {
		// TODO Auto-generated method stub
	

		try
		{
			System.out.println("came.....");
			sessionFactory.getCurrentSession().save(category);
			System.out.println("saved.....");
			return true;
		}
		catch(Exception e)
		{
			System.out.println("not saved.......");
			return false;
		}
		
	}

	@Override
	public boolean deleteCategory(Category category) {
		//category.setActive(false);
		
		try {
			// add the category to the database table
			
			sessionFactory.getCurrentSession().delete(category);
			//,sessionFactory.openSession().clear();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateCategory(Category category,int id) {
		try {
			String id2 = String.valueOf(id);
			// add the category to the database table
			System.out.println("in update dao........");
			sessionFactory.getCurrentSession().merge(id2,category);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}

	@Override
	public List<Category> listCategories() {
			Session session=sessionFactory.openSession();
			Query query=session.createQuery("from Category");
			List<Category>listCategories=query.list();
			session.close();
			return listCategories;
			
				
			
		//return query.getResultList();
	}

	@Override
	public Category getCategory(int categoryId) {
		//return sessionFactory.getCurrentSession().get(Category.class, Integer.valueOf(categoryId));
		Session session=sessionFactory.openSession();
		Category category=session.get(Category.class, categoryId);
		session.close();
		return category;
	}

	
}
