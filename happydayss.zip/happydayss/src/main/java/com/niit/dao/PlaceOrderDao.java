package com.niit.dao;

import java.util.List;

import com.niit.model.OrderedProduct2;
import com.niit.model.PlacingOrder;

public interface PlaceOrderDao {

	public List<PlacingOrder> getPlacedOrder();
	public void saveproductorder(OrderedProduct2 orderedProduct2);
	public List<OrderedProduct2 > getorders();
	public int getCount();
	public OrderedProduct2 getIdOfProductstored();
	public OrderedProduct2 getProducts(long productid);
	public PlacingOrder getLastUpdatedRecored();
	public void savedeliverydetails(PlacingOrder placingOrder);
}
