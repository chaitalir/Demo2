package com.niit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Category;
import com.niit.model.Product;
@Repository("productDao")
@Transactional
public class ProductDaoImpl implements ProductDao {

	@Autowired
	SessionFactory sessionFactory;
	@Override
	public boolean addProduct(Product product) {
		try
		{
			System.out.println("came.....");
			sessionFactory.getCurrentSession().save(product);
			System.out.println("saved.....");
			return true;
		}
		catch(Exception e)
		{
			System.out.println("not saved.......");
			return false;
		}
		
	}

	@Override
	public boolean deleteProduct(Product product) {

		try {
			// add the category to the database table
			
			sessionFactory.getCurrentSession().delete(product);
			//,sessionFactory.openSession().clear();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateProduct(Product product,long id) {
		try {
			String id2 = String.valueOf(id);
			// add the category to the database table
			System.out.println("in update dao........");
			sessionFactory.getCurrentSession().merge(id2,product);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}

	@Override
	public List<Product> listProducts() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Product");
		List<Product>listProducts=query.list();
		session.close();
		return listProducts;
		//return null;
	}

	@Override
	public Product getProduct(long productId) {
		Session session=sessionFactory.openSession();
		Product product=session.get(Product.class, productId);
		session.close();
		return product;
	}

	@Override
	public List<Product> listProducts3() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Product");
		query.setMaxResults(3);
		List<Product>listProducts3=query.list();
		session.close();
		return listProducts3;
	}

	@Override
	public boolean checkProduct(long id,int qty) {
		// TODO Auto-generated method stub
		try
		{
		//getSession().getTransaction().begin();
		String sql="Select e from Product e where e.id=:id";
		Session session=sessionFactory.openSession();
		Query query=session.createQuery(sql);
		query.setParameter("id",id);
		
		Object user1=query.uniqueResult();
		System.out.println("this is upto product checkin.....................");
		if(user1 !=null)
		{
			String sql2="Select e from Product e where e.stock>=:qty";
			Query query2=session.createQuery(sql2);
			Object user12=query.uniqueResult();
			if(user12!=null)
				
			System.out.println("not null........");
			//getSession().getTransaction().commit();
			return true;
		}
		}
		catch(Exception e)
		{
		System.out.println(e);
		}
		return false;
		}

	@Override
	public List<Product> listProducts(String category) {
		Session session=sessionFactory.openSession();
		System.out.println("in dao..of cat");
		Query query=session.createQuery("Select e from Product e where e.category=:category").setParameter("category", category);
		
		List<Product>listProducts=query.list();
		session.close();
		return listProducts;
	}

	
}
