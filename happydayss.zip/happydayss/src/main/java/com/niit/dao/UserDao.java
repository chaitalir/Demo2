package com.niit.dao;

import java.util.List;

import com.niit.model.User;

public interface UserDao {

	public boolean checkLogin(String username, String password);
	public List<User> getAll();
	public boolean register(User user);
}
