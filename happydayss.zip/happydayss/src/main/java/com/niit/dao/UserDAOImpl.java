package com.niit.dao;

import java.util.List;

//import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.CartItem;
//import com.gsmusical.main.Dao.Query;
import com.niit.model.User;

@Repository("userDao")
@Transactional
public class UserDAOImpl implements UserDao {

	
	@Autowired
	SessionFactory sessionFactory;
	public boolean checkLogin(String userName, String password) {
		try
		{
		String sql="Select e from User e where e.userName=:userName and e.password=:password";
		Session session=sessionFactory.openSession();
		Query query=session.createQuery(sql);
		query.setParameter("userName",userName);
		query.setParameter("password",password);
		Object user1=query.uniqueResult();
		System.out.println("this is upto user checkin.....................");
		if(user1 !=null)
		{
			//getSession().getTransaction().commit();
			return true;
		}
		
		
		}
	catch(Exception e)
	{
		//getSession().getTransaction().rollback();
		e.printStackTrace();
	}
		return false;
	}

	public List<User> getAll() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from User");
		List<User>getAll=query.list();
		session.close();
		return getAll;
	}

	@Override
	public boolean register(User user) {
		try
		{
			System.out.println("came.....");
			sessionFactory.getCurrentSession().save(user);
			System.out.println("saved.....");
			return true;
		}
		catch(Exception e)
		{
			System.out.println("not saved.......");
			return false;
		}
		
	}

}
