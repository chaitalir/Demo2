package com.niit.dao;

import java.util.List;

import com.niit.model.Product;

//import com.niit.model.Category;

public interface ProductDao {

	public boolean addProduct(Product product);
	public boolean deleteProduct(Product product);
	public boolean updateProduct(Product product,long id);
	public List <Product> listProducts();
	public Product getProduct(long productId);
	public List<Product> listProducts3();
	public boolean checkProduct(long id,int qty);
	public List<Product> listProducts(String category);
}
