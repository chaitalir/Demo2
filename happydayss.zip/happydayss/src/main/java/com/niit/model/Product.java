package com.niit.model;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

//import com.gsmusical.main.model.Size;

//import org.hibernate.annotations.Entity;

@Entity
@Table(name="product" )
public class Product {

	@Id
	@GeneratedValue
	public long id;
	public String product_name;
	public String category;
	public int price;
	  @Size(min = 2, max = 255)
	public String description;
	public int stock;
	@Size(min = 2, max = 200)
	public String image2;
	
	@Size(min = 2, max = 200)
	public String image3;
	 
	@Size(min = 2, max = 200)
	public String image4;

	public Product() {
		super();
	}

	public Product(long id) {
		super();
		this.id = id;
	}

	public Product( String product_name, String category, int price, String description, int stock,
			String image2, String image3, String image4) {
		super();
		//this.id = id;
		this.product_name = product_name;
		this.category = category;
		this.price = price;
		this.description = description;
		this.stock = stock;
		this.image2 = image2;
		this.image3 = image3;
		this.image4 = image4;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getImage2() {
		return image2;
	}

	public void setImage2(String image2) {
		this.image2 = image2;
	}

	public String getImage3() {
		return image3;
	}

	public void setImage3(String image3) {
		this.image3 = image3;
	}

	public String getImage4() {
		return image4;
	}

	public void setImage4(String image4) {
		this.image4 = image4;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", product_name=" + product_name + ", category=" + category + ", price=" + price
				+ ", description=" + description + ", stock=" + stock + ", image2=" + image2 + ", image3=" + image3
				+ ", image4=" + image4 + "]";
	}
	
}
