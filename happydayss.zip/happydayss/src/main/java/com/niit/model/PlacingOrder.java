package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;



@Entity
@Table(name="placeOrders" )
public class PlacingOrder {

	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 public long id;
	
	 @Size(min = 2, max = 80)
		
	 public String fullname;
	 public long phone;
	 public int pincode;
	 @Size(min = 2, max = 80)
	 public String locality;
	 @Size(min = 2, max = 80)
	 public String address;
	 @Size(min = 2, max = 80)
	 public String city;
	 @Size(min = 2, max = 80)
	 public String state;
	 public String count;
	 public String grandtotal;
	 public String time2;
	 public long productid;
	public PlacingOrder() {
		
	}
	
	public PlacingOrder(long id) {
		
		this.id = id;
	}
	

	public PlacingOrder(String fullname, long phone, int pincode, String locality, String address, String city,
			String state, String count, String grandtotal,String time2,long productid) {
		super();
		this.fullname = fullname;
		this.phone = phone;
		this.pincode = pincode;
		this.locality = locality;
		this.address = address;
		this.city = city;
		this.state = state;
		this.count = count;
		this.grandtotal = grandtotal;
		this.time2 = time2;
		this.productid=productid;
	}

	public long getProductid() {
		return productid;
	}

	public void setProductid(long productid) {
		this.productid = productid;
	}

	public String getTime2() {
		return time2;
	}

	public void setTime2(String time2) {
		this.time2 = time2;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getGrandtotal() {
		return grandtotal;
	}
	public void setGrandtotal(String grandtotal) {
		this.grandtotal = grandtotal;
	}
	 
}
