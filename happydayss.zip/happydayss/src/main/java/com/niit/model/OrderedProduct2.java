package com.niit.model;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="productorderhistorys")
public class OrderedProduct2 {

	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 public long id;
	 public String[]  product_name;
		
		
	 public String[] total;
	 
	 public String[] qty;
	
	 public String[] x2;
	
	 public String count;
	 public String grandtotal;
	public OrderedProduct2() 
	{
		
	}
	public OrderedProduct2(long id)
	{
	
		this.id = id;
	}
	public OrderedProduct2(String[] product_name, String[] total, String[] qty, String[] x2, String count,
			String grandtotal) {
		super();
		this.product_name = product_name;
		this.total = total;
		this.qty = qty;
		this.x2 = x2;
		this.count = count;
		this.grandtotal = grandtotal;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String[] getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String[] product_name) {
		this.product_name = product_name;
	}
	public String[] getTotal() {
		return total;
	}
	public void setTotal(String[] total) {
		this.total = total;
	}
	public String[] getQty() {
		return qty;
	}
	public void setQty(String[] qty) {
		this.qty = qty;
	}
	public String[] getX2() {
		return x2;
	}
	public void setX2(String[] x2) {
		this.x2 = x2;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count.toString();
	}
	public String getGrandtotal() {
		return grandtotal.toString();
	}
	public void setGrandtotal(String grandtotal) {
		this.grandtotal = grandtotal;
	}
	@Override
	public String toString() {
		return "OrderedProduct2 [id=" + id + ", product_name=" + Arrays.toString(product_name) + ", total="
				+ Arrays.toString(total) + ", qty=" + Arrays.toString(qty) + ", x2=" + Arrays.toString(x2) + ", count="
				+ count + ", grandtotal=" + grandtotal + "]";
	}
	
	
}
