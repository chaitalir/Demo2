package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="contact" )
public class Contact {

	@Id
	@GeneratedValue
	int ContactId;
	String name;
	String web;
	String email;
	String subject;
	String msg;
	public Contact() {
		super();
	}
	public Contact(int contactId) {
		super();
		ContactId = contactId;
	}
	public Contact(String name, String web, String email, String subject, String msg) {
		super();
		this.name = name;
		this.web = web;
		this.email = email;
		this.subject = subject;
		this.msg = msg;
	}
	public int getContactId() {
		return ContactId;
	}
	public void setContactId(int contactId) {
		ContactId = contactId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWeb() {
		return web;
	}
	public void setWeb(String web) {
		this.web = web;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	@Override
	public String toString() {
		return "Contact [ContactId=" + ContactId + ", name=" + name + ", web=" + web + ", email=" + email + ", subject="
				+ subject + ", msg=" + msg + "]";
	}
	
}
