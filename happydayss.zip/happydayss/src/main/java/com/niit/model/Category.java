package com.niit.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//import org.hibernate.annotations.Entity;
//import org.hibernate.annotations.Table;
//import org.hibernate.annotations.Table;

@Entity
@Table(name="category" )
public class Category  {

	@Id
	@GeneratedValue
	int CategoryId;
	String maincategory;
	String subcategory;
	String category;
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Category(int categoryId, String maincategory, String subcategory, String category) {
		super();
		CategoryId = categoryId;
		this.maincategory = maincategory;
		this.subcategory = subcategory;
		this.category = category;
	}
	//boolean active;
	public int getCategoryId() {
		return CategoryId;
	}
	public void setCategoryId(int categoryId) {
		System.out.println("in cate.....");
		CategoryId = categoryId;
	}
	public String getMaincategory() {
		return maincategory;
	}
	public void setMaincategory(String maincategory) {
		this.maincategory = maincategory;
	}
	public String getSubcategory() {
		return subcategory;
	}
	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
}
